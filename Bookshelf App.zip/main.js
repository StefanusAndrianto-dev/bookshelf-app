document.addEventListener("DOMContentLoaded", function () {

  let books = [];
  let editingId = null;

  function save() {
    localStorage.setItem("books", JSON.stringify(books));
  }

  function load() {
    const data = localStorage.getItem("books");
    if (data) books = JSON.parse(data);
  }

  function showNotif(msg) {
    const notif = document.getElementById("notif");
    notif.innerText = msg;
    notif.classList.add("show");

    setTimeout(() => {
      notif.classList.remove("show");
    }, 2000);
  }

  function render(data = books) {
    const incomplete = document.getElementById("incompleteBookList");
    const complete = document.getElementById("completeBookList");

    incomplete.innerHTML = "";
    complete.innerHTML = "";

    for (const book of data) {
      const item = document.createElement("div");
      item.setAttribute("data-bookid", book.id);
      item.setAttribute("data-testid", "bookItem");

      item.innerHTML = `
        <h3 data-testid="bookItemTitle">${book.title}</h3>
        <p data-testid="bookItemAuthor">Penulis: ${book.author}</p>
        <p data-testid="bookItemYear">Tahun: ${book.year}</p>
        <div>
          <button data-testid="bookItemIsCompleteButton">
            ${book.isComplete ? "Belum selesai dibaca" : "Selesai dibaca"}
          </button>
          <button data-testid="bookItemDeleteButton">Hapus Buku</button>
          <button data-testid="bookItemEditButton">Edit Buku</button>
        </div>
      `;

      const [toggleBtn, deleteBtn, editBtn] = item.querySelectorAll("button");

      toggleBtn.onclick = () => {
        book.isComplete = !book.isComplete;
        save();
        render();
        showNotif("Status buku diubah");
      };

      deleteBtn.onclick = () => {
        books = books.filter(b => b.id !== book.id);
        save();
        render();
        showNotif("Buku dihapus");
      };

      editBtn.onclick = () => {
        editingId = book.id;

        document.getElementById("bookFormTitle").value = book.title;
        document.getElementById("bookFormAuthor").value = book.author;
        document.getElementById("bookFormYear").value = book.year;
        document.getElementById("bookFormIsComplete").checked = book.isComplete;

        document.getElementById("bookFormSubmit").innerText = "Update Buku";

        window.scrollTo({ top: 0, behavior: "smooth" });
      };

      if (book.isComplete) {
        complete.append(item);
      } else {
        incomplete.append(item);
      }
    }
  }

  document.getElementById("bookForm").addEventListener("submit", function (e) {
    e.preventDefault();

    const title = document.getElementById("bookFormTitle").value;
    const author = document.getElementById("bookFormAuthor").value;
    const year = parseInt(document.getElementById("bookFormYear").value);
    const isComplete = document.getElementById("bookFormIsComplete").checked;

    if (editingId !== null) {
      const book = books.find(b => b.id === editingId);
      if (book) {
        book.title = title;
        book.author = author;
        book.year = year;
        book.isComplete = isComplete;
      }

      editingId = null;
      showNotif("Buku diupdate");

      document.getElementById("bookFormSubmit").innerText =
        "Masukkan Buku ke rak Belum selesai dibaca";

    } else {
      books.push({
        id: Date.now(),
        title,
        author,
        year,
        isComplete
      });

      showNotif("Buku ditambahkan");
    }

    save();
    render();
    this.reset();
  });

  document.getElementById("searchBook").addEventListener("submit", function (e) {
    e.preventDefault();

    const keyword = document
      .getElementById("searchBookTitle")
      .value.toLowerCase();

    const filtered = books.filter(b =>
      b.title.toLowerCase().includes(keyword)
    );

    render(filtered);
  });

  load();
  render();

});